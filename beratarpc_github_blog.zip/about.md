---
layout: page
title: Hakkımda
permalink: /hakkimda/
---

Ben Berat Arpacı. Tasarruf finansman sektöründe müfettiş yardımcısı olarak çalışıyorum. Bu blogda, iç denetim, katılım finans ve sektörel gelişmeleri ele alıyorum.
