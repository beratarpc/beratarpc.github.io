---
layout: page
title: İletişim
permalink: /iletisim/
---

Benimle iletişime geçmek için: info@beratarpaci.com  
LinkedIn: [linkedin.com/in/beratarpaci](https://linkedin.com/in/beratarpaci)
