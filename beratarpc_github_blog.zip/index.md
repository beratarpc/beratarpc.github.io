---
layout: home
title: "Berat Arpacı"
subtitle: "İç Denetim • Katılım Finans • Teftiş"
---

Merhaba, bloguma hoş geldiniz.
